# Instrucciones de funcionamiento.
1. La página principal es el index.html, a partir de este se llaman las otras vistas.
2. Al ingresar en la página se encuentran las instrucciones para realizar todas las operaciones sobre cada una de las tablas, pero de igual manera se explica el proceso a continuación:


* Para ver la lista de una tabla solo debe ingresar a la entidad respectiva en la barra de navegación.
* Si requiere ingresar un registro, rellene los campos del Formulario de registro y oprima guardar.
* Todos los cambios los deberá ver reflejados en la tabla en el instante que realice cualquier acción: Consultaro o Guardar.